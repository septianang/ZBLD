utils::globalVariables(c("number_of_segments", "zb_100_triangular_numbers"))
NULL